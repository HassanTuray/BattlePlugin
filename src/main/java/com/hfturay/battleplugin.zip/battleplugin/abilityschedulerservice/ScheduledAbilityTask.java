package com.hfturay.battleplugin.abilityschedulerservice;

import com.hfturay.battleplugin.BattlePlugin;

public abstract class ScheduledAbilityTask {
    private int ticksRemaining;

    public ScheduledAbilityTask (int delayTicks) {
        this.ticksRemaining = delayTicks;
    }

    public boolean update() {
        ticksRemaining--;
        if (ticksRemaining <= 0) {
            run();
            return true;
        }
        return false;
    }

    public abstract void run();
    
}
