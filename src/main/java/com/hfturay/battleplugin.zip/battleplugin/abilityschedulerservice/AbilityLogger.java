package com.hfturay.battleplugin.abilityschedulerservice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class AbilityLogger {
    private final List<ScheduledAbilityTask> tasks = new ArrayList<>();

    public AbilityLogger(JavaPlugin plugin) {
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    public void schedule(ScheduledAbilityTask task) {
        tasks.add(task);
    }

    private void tick() {
        Iterator<ScheduledAbilityTask> it = tasks.iterator();
        
        while (it.hasNext()) {
            ScheduledAbilityTask task = it.next();
            if (task.update()) { 
                it.remove();
            }
        }
    }
}
