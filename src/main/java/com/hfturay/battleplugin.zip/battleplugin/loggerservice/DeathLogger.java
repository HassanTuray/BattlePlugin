package com.hfturay.battleplugin.loggerservice;

import java.net.http.WebSocket.Listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.PlayerDeathEvent;

public class DeathLogger implements Listener {
    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {

    }
}
