package com.hfturay.battleplugin.ability.abilities.genericabilities;

import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.Particle;

import com.hfturay.battleplugin.BattlePlugin;
import com.hfturay.battleplugin.projectileservice.ParticleEffectCallback;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

import de.slikey.effectlib.EffectManager;
import de.slikey.effectlib.effect.CuboidEffect;
import de.slikey.effectlib.util.ParticleUtil;

public class BrickParticleEffect implements ParticleEffectCallback{
    // private EffectManager effectManager = BattlePlugin.getInstance().getEffectManager();
    // private CuboidEffect brick = new CuboidEffect(effectManager);

    @Override
    public void playParticleEffect(VirtualProjectile virtualProjectile) {
        EffectManager effectManager = BattlePlugin.getInstance().getEffectManager();
        CuboidEffect brick = new CuboidEffect(effectManager);
        brick.particles = 100;
        brick.setLocation(virtualProjectile.getLocation().clone());

        brick.xLength = 1;
        brick.yLength = 1;
        brick.zLength = 1;

        brick.particle = Particle.DUST;
        brick.color = Color.ORANGE;

        brick.period = 1;
        brick.iterations = 1;

        brick.start();
    }
        
    
}
