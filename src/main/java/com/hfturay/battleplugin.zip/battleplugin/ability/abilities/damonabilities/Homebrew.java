package com.hfturay.battleplugin.ability.abilities.damonabilities;

import org.bukkit.Location;
import org.bukkit.util.Vector;

import com.hfturay.battleplugin.BattlePlugin;
import com.hfturay.battleplugin.ability.Ability;
import com.hfturay.battleplugin.ability.abilities.dummyabilities.DummyProjectileCallback;
import com.hfturay.battleplugin.ability.abilities.dummyabilities.DummyProjectileParticleEffectCallback;
import com.hfturay.battleplugin.battleplayer.BattlePlayer;
import com.hfturay.battleplugin.cooldownservice.CooldownLogger;
import com.hfturay.battleplugin.projectileservice.MotionFunction;
import com.hfturay.battleplugin.projectileservice.ProjectileLogger;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;

public class Homebrew extends Ability{
    private double homebrewSpeed = 0.7;
    private int maxTicks = 200;
    private double homebrewHitBox = 0.5;


    public Homebrew(BattlePlayer owner) {
        super(owner);
        
        this.setDisplayName("Homebrew");
        this.setCoolDown(1);

        String abilityNameId = this.getDisplayName().replace(" ", "_");
        String id = owner.getPlayer().getName() + ":" + abilityNameId;
        this.setId(id);
    }

    @Override
    public boolean activate() {
        CooldownLogger cooldownLogger = BattlePlugin.getInstance().getCoolDownLogger();

        if (cooldownLogger.isOnCooldown(owner, this)) {
            long remainingCooldown = cooldownLogger.getRemainingCooldown(owner, this);
            this.owner.getPlayer().sendActionBar(Component.text("Cooldown: " + remainingCooldown + " seconds", NamedTextColor.AQUA).decorate(TextDecoration.BOLD));

            return false;
        }

        BattlePlayer player = this.getOwner();
        Location start = player.getPlayer().getEyeLocation();
        Vector direction = start.getDirection();

        MotionFunction arc = (v, t) -> v.setY(v.getY() - 0.03);
        HomebrewParticleEffect effect = new HomebrewParticleEffect();
        ProjectileLogger pm = BattlePlugin.getInstance().getProjectileLogger();

        VirtualProjectile projectile = new VirtualProjectile(
            start, 
            direction, 
            homebrewSpeed, 
            maxTicks, 
            player, 
            homebrewHitBox, 
            arc,
            new HomebrewCallback(),
            effect
            );
        
        pm.add(projectile);
        cooldownLogger.startCooldown(player, this);

        return true;
    }

    @Override
    public void playParticleEffect() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'playParticleEffect'");
    }
}

