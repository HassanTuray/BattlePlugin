package com.hfturay.battleplugin.ability;

public class AbilityContext {
    long invokeTime; 

}
