package com.hfturay.battleplugin.ability;

import java.lang.reflect.Constructor;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.hfturay.battleplugin.ability.abilities.damonabilities.Disengage;
import com.hfturay.battleplugin.ability.abilities.damonabilities.Homebrew;
import com.hfturay.battleplugin.ability.abilities.damonabilities.LandMine;
import com.hfturay.battleplugin.ability.abilities.damonabilities.Lazer;
import com.hfturay.battleplugin.ability.abilities.damonabilities.SwitchOnALazer;
import com.hfturay.battleplugin.ability.abilities.dummyabilities.DummyAOE;
import com.hfturay.battleplugin.ability.abilities.dummyabilities.DummyFallDamageImmunity;
import com.hfturay.battleplugin.ability.abilities.dummyabilities.DummyHitScan;
import com.hfturay.battleplugin.ability.abilities.dummyabilities.DummyHitScanBlocks;
import com.hfturay.battleplugin.ability.abilities.dummyabilities.DummyProjectile;
import com.hfturay.battleplugin.ability.abilities.genericabilities.Adrenaline;
import com.hfturay.battleplugin.ability.abilities.genericabilities.Brick;
import com.hfturay.battleplugin.ability.abilities.genericabilities.Leap;
import com.hfturay.battleplugin.battleplayer.BattlePlayer;

public class AbilityFactory {
    private String KingGorbnakID = "9879aa16-ac68-3671-97cd-94014f583414";

    private Map<UUID, List<Class<? extends Ability>>> attackLoadouts = Map.of(
        UUID.fromString(KingGorbnakID), List.of(Brick.class, Homebrew.class, Lazer.class, LandMine.class)
    );

    private Map<UUID, List<Class<? extends Ability>>> mobilityLoadouts = Map.of(
        UUID.fromString(KingGorbnakID), List.of(Leap.class, Disengage.class)
    );

    private Map<UUID, List<Class<? extends Ability>>> buffLoadouts = Map.of(
        UUID.fromString(KingGorbnakID), List.of(Adrenaline.class, SwitchOnALazer.class)
    ); 

    public void assignAbilities(BattlePlayer battlePlayer) {
        UUID uuid = battlePlayer.getPlayer().getUniqueId();

        for (Class<? extends Ability> abilityClass : 
            attackLoadouts.getOrDefault(uuid, List.of())) {

            battlePlayer.getAttackAbilities().add(instantiate(abilityClass, battlePlayer));
        }

        for (Class<? extends Ability> abilityClass : 
            mobilityLoadouts.getOrDefault(uuid, List.of())) {

            battlePlayer.getMobilityAbilities().add(instantiate(abilityClass, battlePlayer));
        }

        for (Class<? extends Ability> abilityClass : 
            buffLoadouts.getOrDefault(uuid, List.of())) {

            battlePlayer.getBuffAbilities().add(instantiate(abilityClass, battlePlayer));
        }
    }

    private Ability instantiate(Class<? extends Ability> abilityClass, BattlePlayer owner) {
        try {
            Constructor<? extends Ability> abilityConstructor = abilityClass.getConstructor(BattlePlayer.class);
            return abilityConstructor.newInstance(owner);

        } catch (Exception e) {
            throw new RuntimeException("Failed to instantiate ability: " + abilityClass.getName(), e);
        }
    }
}
