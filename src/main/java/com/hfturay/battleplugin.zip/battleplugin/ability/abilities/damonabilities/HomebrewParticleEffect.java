package com.hfturay.battleplugin.ability.abilities.damonabilities;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.util.Vector;

import com.hfturay.battleplugin.BattlePlugin;
import com.hfturay.battleplugin.projectileservice.ParticleEffectCallback;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

import de.slikey.effectlib.EffectManager;
import de.slikey.effectlib.effect.LineEffect;
import de.slikey.effectlib.effect.SphereEffect;

public class HomebrewParticleEffect implements ParticleEffectCallback {
    private float brewBodyDustSize = 0.5f;
    private double brewBodyRadius = 0.05;
    private int brewBodyNumParticles = 50;

    private EffectManager effectManager = BattlePlugin.getInstance().getEffectManager();
    private SphereEffect brewBody = new SphereEffect(effectManager);

    @Override
    public void playParticleEffect(VirtualProjectile virtualProjectile) {
        Location projectileLocation = virtualProjectile.getLocation().clone();

        brewBody.setLocation(projectileLocation);
        brewBody.particle = Particle.DUST;
        brewBody.color = Color.GREEN;
        brewBody.radius = brewBodyRadius;
        brewBody.particles = brewBodyNumParticles;
        brewBody.iterations = 1;
        brewBody.particleData = 0.01f;
        brewBody.period = 1;

        // LineEffect brewStink = new LineEffect(effectManager);

        // brewStink.particle = Particle.DUST;
        // brewStink.color = Color.PURPLE;
        // brewStink.particleCount = 1;
        // brewStink.particleSize = 0.5f;
        // brewStink.setLocation(projectileLocation.add(0,0.5,0));
        // brewStink.iterations = 1;
        // brewStink.isZigZag = true;
        // brewStink.period = 1;
        // brewStink.zigZags = 2;
        // brewStink.zigZagOffset = new Vector(0.01, 0, 0.01);

        // brewStink.setTarget(projectileLocation.add(0,1,0));
        
        brewBody.start();
        // brewStink.start();
    }
    
}
