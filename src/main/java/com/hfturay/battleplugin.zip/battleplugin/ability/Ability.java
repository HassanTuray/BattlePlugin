package com.hfturay.battleplugin.ability;

import com.hfturay.battleplugin.battleplayer.BattlePlayer;

public abstract class Ability {
    private String id;
    private String displayName;
    private long cooldown;
    public final BattlePlayer owner;

    // context enum needed
    // result enum needed
    // interupt enum needed

    public abstract boolean activate(); 
    public abstract void playParticleEffect();

    public Ability(BattlePlayer owner) {
        this.owner = owner;
    }
    
    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getCooldown() {
        return cooldown;
    }

    public void setCoolDown(long cooldown) {
        this.cooldown = cooldown;
    }

    public BattlePlayer getOwner() {
        return this.owner;
    }
}
