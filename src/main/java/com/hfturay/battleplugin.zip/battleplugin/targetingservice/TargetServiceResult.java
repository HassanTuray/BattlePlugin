package com.hfturay.battleplugin.targetingservice;

public enum TargetServiceResult {
    NO_TARGET,
    TARGET
}

