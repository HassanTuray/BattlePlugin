package com.hfturay.battleplugin.projectileservice;

import java.util.function.Predicate;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import com.hfturay.battleplugin.BattlePlugin;
import com.hfturay.battleplugin.ability.abilities.dummyabilities.DummyProjectileParticleEffectCallback;
import com.hfturay.battleplugin.battleplayer.BattlePlayer;

import de.slikey.effectlib.EffectManager;
import de.slikey.effectlib.effect.DnaEffect;
import de.slikey.effectlib.effect.ParticleEffect;
import de.slikey.effectlib.effect.SphereEffect;

public class VirtualProjectile {
    private Location location;
    private Vector direction;
    private double speed;
    private int maxTicks;
    private BattlePlayer owner;
    private int ticksLived = 0;
    private MotionFunction motionFunction;
    private ProjectileHitCallback callback;
    private double hitbox;
    private ParticleEffectCallback effect;

    private Vector velocity;
    
    // private ProjectileHitCallback callback;
    
    public VirtualProjectile(
        Location start, 
        Vector direction, 
        double speed, 
        int maxTicks, 
        BattlePlayer owner, 
        double hitbox, 
        ProjectileHitCallback callback,
        ParticleEffectCallback effect) 
    {
        this.location = start.clone();
        this.direction = direction.clone().normalize();
        this.speed = speed;
        this.maxTicks = maxTicks;
        this.owner = owner;
        this.motionFunction = (v, t) -> v;

        this.callback = callback;
        this.velocity = direction.clone().multiply(speed);
        this.effect = effect;
    }

    public VirtualProjectile(
        Location start, 
        Vector direction, 
        double speed, 
        int maxTicks, 
        BattlePlayer owner, 
        double hitbox, 
        MotionFunction motionFunction,
        ProjectileHitCallback callback,
        ParticleEffectCallback effect) 
    
    {
        this.location = start.clone();
        this.direction = direction.clone().normalize();
        this.speed = speed;
        this.maxTicks = maxTicks;
        this.owner = owner;
        this.motionFunction = motionFunction;

        this.callback = callback;
        this.velocity = direction.clone().multiply(speed);
        this.effect = effect;
    }

    public boolean tick() {
        ticksLived++;
        
        velocity = motionFunction.apply(velocity, ticksLived);

        location.add(velocity);
        
        effect.playParticleEffect(this);

        Entity hit = getHitEntity(this.hitbox);
        if (hit != null && !hit.equals(owner.getPlayer())) {
            callback.onHit(new ProjectileHitResult(hit, location), owner);
            return true; 
        }

        if (!location.getBlock().isPassable()) {
            callback.onHit(new ProjectileHitResult(location.getBlock(), location), owner);
            return true;
        }
        
        if (ticksLived >= maxTicks) {
            return true;
        }

        return false;
    }

    public double getHitbox() {
        return hitbox;
    }

    public void setHitbox(double hitbox) {
        this.hitbox = hitbox;
    }

    private Entity getHitEntity(double hitbox) {
        Predicate<Entity> playersAndMobsFilter =  entity -> (entity instanceof Player) || (entity instanceof Mob);

        for (Entity entity : location.getWorld().getNearbyEntities(location, hitbox, hitbox, hitbox)) {
            if (playersAndMobsFilter.test(entity)) {
                return entity;
            }
        }
        return null;
    }

    public Location getLocation() {
        return this.location;
    }
}
