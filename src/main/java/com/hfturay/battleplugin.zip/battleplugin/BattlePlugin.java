package com.hfturay.battleplugin;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.plugin.PluginManager;

import com.hfturay.battleplugin.ability.AbilityFactory;
import com.hfturay.battleplugin.abilityschedulerservice.AbilityLogger;
import com.hfturay.battleplugin.clickservice.ClickLogger;
import com.hfturay.battleplugin.cooldownservice.CooldownLogger;
import com.hfturay.battleplugin.falldamageservice.FallDamageLogger;
import com.hfturay.battleplugin.falldamageservice.FallDamageService;
import com.hfturay.battleplugin.loggerservice.PlayerLogger;
import com.hfturay.battleplugin.projectileservice.ProjectileLogger;

import de.slikey.effectlib.EffectManager;


public class BattlePlugin extends org.bukkit.plugin.java.JavaPlugin {
    private static BattlePlugin instance;
    private World world; 
    private AbilityFactory abilityFactory;
    private CooldownLogger cooldownLogger;
    private ProjectileLogger projectileLogger;
    private EffectManager effectManager;
    private FallDamageService fallDamageService;
    private AbilityLogger abilityLogger;

    @Override
    public void onEnable() {
        instance = this;
        world = Bukkit.getWorld("world");
        abilityFactory = new AbilityFactory();
        cooldownLogger = new CooldownLogger();
        projectileLogger = new ProjectileLogger();
        effectManager = new EffectManager(this);
        fallDamageService = new FallDamageService();
        abilityLogger = new AbilityLogger(this);

        // load config files
        // Initialize services like, cooldown, effects, click timer
        // register listeners like click handler
        // register commands
        getLogger().info("BattlePlugin enabled!");

        projectileLogger.start();

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new PlayerLogger(), this);
        pm.registerEvents(new ClickLogger(), this);
        pm.registerEvents(new FallDamageLogger(), this);
    }

    @Override 
    public void onDisable() {
        if (effectManager != null) {
            effectManager.dispose();
        }

        instance = null;
        getLogger().info("BattlePlugin Disabled");
    }

    public static BattlePlugin getInstance() {
        return instance;
    }

    public AbilityFactory getAbilityFactory() {
        return abilityFactory;
    }

    public World getWorld() {
        return world;
    }

    public CooldownLogger getCoolDownLogger() {
        return cooldownLogger;
    }

    public ProjectileLogger getProjectileLogger() {
        return projectileLogger;
    }

    public EffectManager getEffectManager() {
        return effectManager;
    }

    public FallDamageService getFallDamageService() {
        return fallDamageService;
    }

    public AbilityLogger getAbilityLogger() {
        return abilityLogger;
    }
}
