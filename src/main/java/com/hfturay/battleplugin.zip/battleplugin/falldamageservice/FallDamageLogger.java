package com.hfturay.battleplugin.falldamageservice;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import com.hfturay.battleplugin.BattlePlugin;

public class FallDamageLogger implements Listener {
    @EventHandler
    public void onFallDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player player)) {
            return;
        }

        if (e.getCause() == EntityDamageEvent.DamageCause.FALL) {

            FallDamageService service = BattlePlugin.getInstance().getFallDamageService();

            if (service.hasFallImmunity(player)) {
                e.setCancelled(true);
                service.clearFallImmunity(player); 
            }
        }
    }
    
    @EventHandler
    public void onPlayerMove(PlayerMoveEvent e) {
        Player player = e.getPlayer();
        Entity entity = player; 

        FallDamageService service = BattlePlugin.getInstance().getFallDamageService();
        if (!service.hasFallImmunity(player)) {
            return;
        }

        if (player.getVelocity().getY() == 0 && entity.isOnGround()) {
            service.clearFallImmunity(player);
        }
    }
}
