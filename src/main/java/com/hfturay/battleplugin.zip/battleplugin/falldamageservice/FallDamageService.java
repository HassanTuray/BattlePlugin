package com.hfturay.battleplugin.falldamageservice;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import org.bukkit.entity.Player;

import com.hfturay.battleplugin.BattlePlugin;

public class FallDamageService {
    private final Set<UUID> fallImmunity = new HashSet<>();

    public void grantFallImmunity(Player player) {
        fallImmunity.add(player.getUniqueId());
    }

    public boolean hasFallImmunity(Player player) {
        return fallImmunity.contains(player.getUniqueId());
    }

    public void clearFallImmunity(Player player) {
        fallImmunity.remove(player.getUniqueId());
    }
}
