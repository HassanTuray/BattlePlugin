package com.hfturay.battleplugin.ability.abilities.genericabilities;

import org.bukkit.Color;
import org.bukkit.Particle;

import com.hfturay.battleplugin.BattlePlugin;
import com.hfturay.battleplugin.customeffects.ProjectileParticleEffect;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

import de.slikey.effectlib.EffectManager;
import de.slikey.effectlib.effect.CubeEffect;

public class BrickParticleEffect extends ProjectileParticleEffect {
    private  EffectManager effectManager = BattlePlugin.getInstance().getEffectManager();
    private  CubeEffect brick = new CubeEffect(effectManager);

    protected BrickParticleEffect(VirtualProjectile vp) {
        super(vp);

        this.effect = brick;

        brick.particle = Particle.DUST;
        brick.color = Color.ORANGE;
        brick.particles = 20;
        brick.particleSize = 0.1f;

        brick.edgeLength = 0.15f;

        brick.period = 1;
        brick.iterations = -1;

        brick.outlineOnly = false;
    }
    
}
