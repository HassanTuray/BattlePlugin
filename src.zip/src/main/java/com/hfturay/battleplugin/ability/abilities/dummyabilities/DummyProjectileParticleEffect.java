package com.hfturay.battleplugin.ability.abilities.dummyabilities;

import com.hfturay.battleplugin.customeffects.ProjectileParticleEffect;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

public class DummyProjectileParticleEffect extends ProjectileParticleEffect {

    protected DummyProjectileParticleEffect(VirtualProjectile vp) {
        super(vp);
    }  
}
