package com.hfturay.battleplugin.ability.abilities.muhammadabilities;

import org.bukkit.Location;
import org.bukkit.util.Vector;

import com.hfturay.battleplugin.BattlePlugin;
import com.hfturay.battleplugin.ability.Ability;
import com.hfturay.battleplugin.ability.abilities.dummyabilities.DummyProjectileCallback;
import com.hfturay.battleplugin.ability.abilities.dummyabilities.DummyProjectileParticleEffectCallback;
import com.hfturay.battleplugin.battleplayer.BattlePlayer;
import com.hfturay.battleplugin.cooldownservice.CooldownLogger;
import com.hfturay.battleplugin.projectileservice.MotionFunction;
import com.hfturay.battleplugin.projectileservice.ProjectileLogger;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;

public class MetldownOfWaves extends Ability {
    private double waveSpeed = 0.5;
    private double waveHitBox = 3;
    private int maxTicks = 100;

    public MetldownOfWaves(BattlePlayer owner) {
        super(owner);
        
        this.setDisplayName("Meltdown of Waves");
        this.setCoolDown(10);

        String abilityNameId = this.getDisplayName().replace(" ", "_");
        String id = owner.getPlayer().getName() + ":" + abilityNameId;
        this.setId(id);
    }

    @Override
    public boolean activate() {
        CooldownLogger cooldownLogger = BattlePlugin.getInstance().getCoolDownLogger();

        if (cooldownLogger.isOnCooldown(owner, this)) {
            long remainingCooldown = cooldownLogger.getRemainingCooldown(owner, this);
            this.owner.getPlayer().sendActionBar(Component.text("Cooldown: " + remainingCooldown + " seconds", NamedTextColor.AQUA).decorate(TextDecoration.BOLD));

            return false;
        }

        BattlePlayer player = this.getOwner();
        Location start = player.getPlayer().getEyeLocation().add(0, -0.15, 0);
        Vector direction = start.getDirection();

        MeltdownOfWavesParticleEffect effect = new MeltdownOfWavesParticleEffect();
        ProjectileLogger pm = BattlePlugin.getInstance().getProjectileLogger();

        VirtualProjectile projectile = new VirtualProjectile (
            start,  
            direction, 
            waveSpeed, 
            maxTicks, 
            player, 
            waveHitBox, 
            new MeltdownOfWavesCallback(),
            effect
        );
        
        projectile.setParticleEffectPeriod(2);
        projectile.setStopOnHitPlayer(false);
        projectile.setStopOnHitBlock(false);
        projectile.setHitBlocks(false);

        pm.add(projectile);
        cooldownLogger.startCooldown(player, this);

        return true;
    }

    @Override
    public void playParticleEffect() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'playParticleEffect'");
    }
    
}
