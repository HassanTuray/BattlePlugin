package com.hfturay.battleplugin.ability.abilities.dummyabilities;

import com.hfturay.battleplugin.projectileservice.ParticleEffectCallback;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

public class DummyProjectileParticleEffectCallbackx implements ParticleEffectCallback {
    @Override
    public void playParticleEffect(VirtualProjectile virtualProjectile) {
        
    }
}
