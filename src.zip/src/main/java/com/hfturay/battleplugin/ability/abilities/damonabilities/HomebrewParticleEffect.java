package com.hfturay.battleplugin.ability.abilities.damonabilities;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;

import com.hfturay.battleplugin.BattlePlugin;
import com.hfturay.battleplugin.customeffects.ProjectileParticleEffect;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

import de.slikey.effectlib.EffectManager;
import de.slikey.effectlib.effect.SphereEffect;

public class HomebrewParticleEffect extends ProjectileParticleEffect {
    private EffectManager effectManager = BattlePlugin.getInstance().getEffectManager();
    private SphereEffect brewBody = new SphereEffect(effectManager);

    public HomebrewParticleEffect(VirtualProjectile vp) {
        super(vp);

        brewBody.particle = Particle.DUST;
        brewBody.color = Color.GREEN;
        brewBody.radius = 0.05;
        brewBody.particles = 50;
        brewBody.iterations = 1;
        brewBody.particleData = 0.01f;
        brewBody.period = 1;

        this.effect = brewBody;
    }
    
}
