package com.hfturay.battleplugin.ability.abilities.muhammadabilities;

import org.bukkit.Location;
import org.bukkit.util.Vector;

import com.hfturay.battleplugin.BattlePlugin;
import com.hfturay.battleplugin.ability.Ability;
import com.hfturay.battleplugin.ability.abilities.damonabilities.HomebrewCallback;
import com.hfturay.battleplugin.ability.abilities.damonabilities.HomebrewParticleEffect;
import com.hfturay.battleplugin.battleplayer.BattlePlayer;
import com.hfturay.battleplugin.cooldownservice.CooldownLogger;
import com.hfturay.battleplugin.projectileservice.MotionFunction;
import com.hfturay.battleplugin.projectileservice.ProjectileLogger;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;

public class PipeBomb extends Ability {
    private double pipeBombSpeed = 1;
    private int maxTicks = 200;
    private double pipeBombHitBox = 0.5;

    public PipeBomb(BattlePlayer owner) {
        super(owner);
        
        this.setDisplayName("Pipebomb");
        this.setCoolDown(8);

        String abilityNameId = this.getDisplayName().replace(" ", "_");
        String id = owner.getPlayer().getName() + ":" + abilityNameId;
        this.setId(id);
    }

    @Override
    public boolean activate() {
        CooldownLogger cooldownLogger = BattlePlugin.getInstance().getCoolDownLogger();

        if (cooldownLogger.isOnCooldown(owner, this)) {
            long remainingCooldown = cooldownLogger.getRemainingCooldown(owner, this);
            this.owner.getPlayer().sendActionBar(Component.text("Cooldown: " + remainingCooldown + " seconds", NamedTextColor.AQUA).decorate(TextDecoration.BOLD));

            return false;
        }

        BattlePlayer player = this.getOwner();
        Location start = player.getPlayer().getEyeLocation();
        Vector direction = start.getDirection();

        MotionFunction arc = (v, t) -> v.setY(v.getY() - 0.03);
        PipeBombParticleEffect effect = new PipeBombParticleEffect();
        ProjectileLogger pm = BattlePlugin.getInstance().getProjectileLogger();

        VirtualProjectile projectile = new VirtualProjectile(
            start, 
            direction, 
            pipeBombSpeed, 
            maxTicks, 
            player, 
            pipeBombHitBox, 
            arc,
            new PipeBombCallBack(),
            effect
            );
        
        pm.add(projectile);
        cooldownLogger.startCooldown(player, this);

        return true;
    }

    @Override
    public void playParticleEffect() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'playParticleEffect'");
    }
    
}
