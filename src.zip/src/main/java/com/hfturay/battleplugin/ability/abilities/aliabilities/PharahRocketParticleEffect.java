package com.hfturay.battleplugin.ability.abilities.aliabilities;

import com.hfturay.battleplugin.ability.Ability;
import com.hfturay.battleplugin.projectileservice.ParticleEffectCallback;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

public class PharahRocketParticleEffect implements ParticleEffectCallback {

    @Override
    public void playParticleEffect(VirtualProjectile virtualProjectile) {
        
    }
}
