package com.hfturay.battleplugin.ability.abilities.aliabilities;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.util.Vector;

import com.hfturay.battleplugin.BattlePlugin;
import com.hfturay.battleplugin.customeffects.ProjectileParticleEffect;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

import de.slikey.effectlib.Effect;
import de.slikey.effectlib.EffectManager;
import de.slikey.effectlib.effect.CubeEffect;
import de.slikey.effectlib.effect.ParticleEffect;

public class PharahRocketParticleEffect extends ProjectileParticleEffect {
    private EffectManager em = BattlePlugin.getInstance().getEffectManager();
    private CubeEffect nose = new CubeEffect(em);
    private CubeEffect body1 = new CubeEffect(em);
    private CubeEffect body2 = new CubeEffect(em);
    private ParticleEffect flame = new ParticleEffect(em);

    private float edge = 0.4f;

    public PharahRocketParticleEffect(VirtualProjectile vp) {
        super(vp);

        effects.add(nose);
        effects.add(body1);
        effects.add(body2);
        effects.add(flame);

        nose.particle = Particle.DUST;
        nose.color = Color.RED;
        nose.particles = 5;
        nose.particleSize = 0.5f;

        nose.outlineOnly = false;
        nose.orient = true;
        nose.enableRotation = false;
        nose.edgeLength = 0.2f;

        nose.period = 1;
        nose.iterations = 1;

        effects.add(body1);
    
        body1.particle = Particle.DUST;
        body1.color = Color.WHITE;
        body1.particles = 10;
        body1.particleSize = 0.5f;

        body1.outlineOnly = false;
        body1.orient = true;
        body1.enableRotation = false;
        body1.edgeLength = edge;

        body1.period = 1;
        body1.iterations = 1;

        effects.add(body1);
        
        body2.particle = Particle.DUST;
        body2.color = Color.WHITE;
        body2.particles = 10;
        body2.particleSize = 0.5f;

        body2.outlineOnly = false;
        body2.orient = true;
        body2.enableRotation = false;
        body2.edgeLength = edge;

        body2.period = 1;
        body2.iterations = 1;

        flame.particle = Particle.FLAME;
        flame.particleCount = 5;

        flame.period = 1;
        flame.iterations = 1;
    }

    @Override
    public void playParticleEffect() { 
        Location projectileLocation = vp.getLocation();
        Vector forward = vp.getDirection().clone().normalize();
        Location cubeLocation = projectileLocation.clone().add(forward.clone().multiply(-0.4f));
        
        Location flameLocation = projectileLocation.clone().add(forward.clone().multiply(-1.1));
        
        for (Effect effect : effects) {
            if (!effect.isPlaying()) {
                effect.start();
            }
        }

        nose.setLocation(projectileLocation);
        body1.setLocation(cubeLocation);
        body2.setLocation(cubeLocation);
        flame.setLocation(flameLocation);
    }
}
