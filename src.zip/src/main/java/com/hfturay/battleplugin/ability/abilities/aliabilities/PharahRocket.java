package com.hfturay.battleplugin.ability.abilities.aliabilities;

import org.bukkit.Location;
import org.bukkit.util.Vector;

import com.hfturay.battleplugin.BattlePlugin;
import com.hfturay.battleplugin.ability.Ability;
import com.hfturay.battleplugin.ability.abilities.nathanabilities.OrbThrowParticleEffect;
import com.hfturay.battleplugin.ability.abilities.nathanabilities.OrbThrowRepeater;
import com.hfturay.battleplugin.abilityschedulerservice.AbilityLogger;
import com.hfturay.battleplugin.battleplayer.BattlePlayer;
import com.hfturay.battleplugin.projectileservice.ProjectileLogger;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

public class PharahRocket extends Ability {
    private double rocketSpeed = 1.2;
    private int maxTicks = 100;
    private double rocketHitbox = 1;

    public PharahRocket(BattlePlayer owner) {
        super(owner);
        
        this.setDisplayName("Pharah Rocket");
        this.setCoolDown(1);

        String abilityNameId = this.getDisplayName().replace(" ", "_");
        String id = owner.getPlayer().getName() + ":" + abilityNameId;
        this.setId(id);
    }

    @Override
    public boolean activate() {
        BattlePlayer player = this.getOwner();
        Location start = player.getPlayer().getEyeLocation();
        Vector direction = start.getDirection();

        ProjectileLogger pm = BattlePlugin.getInstance().getProjectileLogger();

        VirtualProjectile projectile = new VirtualProjectile(
            start, 
            direction, 
            rocketSpeed, 
            maxTicks, 
            player, 
            1, 
            new PharahRocketCallback(),
            new OrbThrowParticleEffect()
        );
        
        projectile.setParticleEffectPeriod(2);
        projectile.setStopOnHitPlayer(false);
        
        pm.add(projectile);

        OrbThrowRepeater repeater = new OrbThrowRepeater(maxTicks, projectile, start);
        AbilityLogger abilityLogger = BattlePlugin.getInstance().getAbilityLogger();
        abilityLogger.schedule(repeater);

        cooldownLogger.startCooldown(player, this);

        return true;
    }

    @Override
    public void playParticleEffect() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'playParticleEffect'");
    }
    
}
