package com.hfturay.battleplugin.ability.abilities.nathanabilities;

import org.bukkit.Location;
import org.bukkit.util.Vector;

import com.hfturay.battleplugin.BattlePlugin;
import com.hfturay.battleplugin.ability.Ability;
import com.hfturay.battleplugin.ability.abilities.muhammadabilities.AnthraxPackageCallBack;
import com.hfturay.battleplugin.ability.abilities.muhammadabilities.AnthraxPackageParticleEffect;
import com.hfturay.battleplugin.abilityschedulerservice.AbilityLogger;
import com.hfturay.battleplugin.battleplayer.BattlePlayer;
import com.hfturay.battleplugin.cooldownservice.CooldownLogger;
import com.hfturay.battleplugin.projectileservice.MotionFunction;
import com.hfturay.battleplugin.projectileservice.ProjectileLogger;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;

public class OrbThrow extends Ability {
    private double orbSpeed = 0.8;
    private double orbHitbox = 0.45;
    private int maxTicks = 300;

    public OrbThrowCallback orbThrowCallback = new OrbThrowCallback();

    public OrbThrow(BattlePlayer owner) {
        super(owner);
        
        this.setDisplayName("Orb Throw");
        this.setCoolDown(1);
        
        String abilityNameId = this.getDisplayName().replace(" ", "_");
        String id = owner.getPlayer().getName() + ":" + abilityNameId;
        this.setId(id);
    }

    @Override
    public boolean activate() {
        CooldownLogger cooldownLogger = BattlePlugin.getInstance().getCoolDownLogger();

        if (cooldownLogger.isOnCooldown(owner, this)) {
            long remainingCooldown = cooldownLogger.getRemainingCooldown(owner, this);
            this.owner.getPlayer().sendActionBar(Component.text("Cooldown: " + remainingCooldown + " seconds", NamedTextColor.AQUA).decorate(TextDecoration.BOLD));

            return false;
        }

        BattlePlayer player = this.getOwner();
        Location start = player.getPlayer().getEyeLocation();
        Vector direction = start.getDirection();

        ProjectileLogger pm = BattlePlugin.getInstance().getProjectileLogger();

        VirtualProjectile projectile = new VirtualProjectile(
            start, 
            direction, 
            orbSpeed, 
            maxTicks, 
            player, 
            orbHitbox, 
            orbThrowCallback,
            new OrbThrowParticleEffect()
        );
        
        projectile.setParticleEffectPeriod(2);
        projectile.setStopOnHitPlayer(false);
        
        pm.add(projectile);

        OrbThrowRepeater repeater = new OrbThrowRepeater(maxTicks, projectile, start);
        AbilityLogger abilityLogger = BattlePlugin.getInstance().getAbilityLogger();
        abilityLogger.schedule(repeater);

        cooldownLogger.startCooldown(player, this);

        return true;
    }

    @Override
    public void playParticleEffect() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'playParticleEffect'");
    }
}
