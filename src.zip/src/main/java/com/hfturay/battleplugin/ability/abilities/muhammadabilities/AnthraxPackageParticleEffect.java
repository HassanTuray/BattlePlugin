package com.hfturay.battleplugin.ability.abilities.muhammadabilities;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;

import com.hfturay.battleplugin.BattlePlugin;
import com.hfturay.battleplugin.customeffects.ProjectileParticleEffect;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

import de.slikey.effectlib.Effect;
import de.slikey.effectlib.EffectManager;
import de.slikey.effectlib.effect.SphereEffect;

public class AnthraxPackageParticleEffect extends ProjectileParticleEffect {
    private EffectManager effectManager = BattlePlugin.getInstance().getEffectManager();
    private SphereEffect dragonBallBlack = new SphereEffect(effectManager);
    private SphereEffect dragonBallGreen = new SphereEffect(effectManager);
    protected AnthraxPackageParticleEffect(VirtualProjectile vp) {
        super(vp);
        
        effects.add(dragonBallBlack);
        effects.add(dragonBallGreen);

        dragonBallBlack.setLocation(vp.getLocation());

        dragonBallBlack.iterations = 2;
        dragonBallBlack.period = 1;

        dragonBallBlack.particle = Particle.DUST; 
        dragonBallBlack.color = Color.BLACK;
        dragonBallBlack.particles = 25;
        dragonBallBlack.particleSize = 0.2f;

        dragonBallBlack.radius = 0.1;

        dragonBallGreen.setLocation(vp.getLocation());

        dragonBallGreen.iterations = 2;
        dragonBallGreen.period = 1;

        dragonBallGreen.particle = Particle.DUST; 
        dragonBallGreen.color = Color.LIME;
        dragonBallGreen.particles = 25;
        dragonBallGreen.particleSize = 0.2f;

        dragonBallGreen.radius = 0.1;
    }

    @Override
    public void playParticleEffect() {

        for (Effect effect : effects) {
            if (!effect.isPlaying()) {
                effect.start();
            }
        }

        Location projectileLocation = vp.getLocation();
        dragonBallBlack.setLocation(projectileLocation);
        dragonBallGreen.setLocation(projectileLocation);
    }    
}
