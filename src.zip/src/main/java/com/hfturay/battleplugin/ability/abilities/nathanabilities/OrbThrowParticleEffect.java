package com.hfturay.battleplugin.ability.abilities.nathanabilities;

import org.bukkit.Color;
import org.bukkit.Particle;

import com.hfturay.battleplugin.BattlePlugin;
import com.hfturay.battleplugin.customeffects.ProjectileParticleEffect;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

import de.slikey.effectlib.EffectManager;
import de.slikey.effectlib.effect.AtomEffect;

public class OrbThrowParticleEffect extends ProjectileParticleEffect {
    private EffectManager effectManager = BattlePlugin.getInstance().getEffectManager();
    private AtomEffect atom = new AtomEffect(effectManager);

    protected OrbThrowParticleEffect(VirtualProjectile vp) {
        super(vp);

        this.effect = atom;

        atom.setLocation(vp.getLocation());

        atom.particleOrbital = Particle.DUST;
        atom.colorOrbital = Color.FUCHSIA;
        atom.particleNucleus = Particle.DUST;
        atom.colorNucleus = Color.PURPLE; 

        atom.period = 1;
        atom.iterations = 3;

        atom.radiusNucleus = 0.1f;
        atom.radius = 0.3f;

        atom.particleSize = 0.5f;

        atom.particlesNucleus = 20;
        atom.particlesOrbital = 20;
        atom.orbitals = 2;

        atom.angularVelocity = Math.PI / 32;
        atom.orient = true;

    }
    
}
