package com.hfturay.battleplugin.abilityschedulerservice;

import com.hfturay.battleplugin.ability.Ability;

public abstract class ScheduledAbilityTask {
    protected int ticksRemaining;
    protected Ability ability;

    public ScheduledAbilityTask (int duration, Ability ability) {
        this.ticksRemaining = duration;
        this.ability = ability;
    }

    public boolean update() {
        ticksRemaining--;
        if (ticksRemaining <= 0) {
            run();
            return true;
        }
        return false;
    }

    public int getTicksRemaining() {
        return ticksRemaining;
    }

    public void setTicksRemaining(int ticks) {
        this.ticksRemaining = ticks;
    }

    public void cancel() {
        ticksRemaining = 0;
    }

    public abstract void run();
    
}
