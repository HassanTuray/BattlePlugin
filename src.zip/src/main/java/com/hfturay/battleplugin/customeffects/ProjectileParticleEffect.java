package com.hfturay.battleplugin.customeffects;

import java.util.ArrayList;

import com.hfturay.battleplugin.ability.Ability;
import com.hfturay.battleplugin.projectileservice.VirtualProjectile;

import de.slikey.effectlib.Effect;

public abstract class ProjectileParticleEffect {
    protected Ability ab;
    protected VirtualProjectile vp;
    protected Effect effect;
    protected ArrayList<Effect> effects = new ArrayList<Effect>();

    protected ProjectileParticleEffect(VirtualProjectile vp) {
        this.vp = vp;
    }

    public void playParticleEffect() {
        if (!effect.isPlaying()) {
            effect.start();
        }
        effect.setLocation(vp.getLocation());
    }

    public void cancel() {
        if (effects.size() == 0) {
            effect.cancel();
        } else {
            for (Effect effect : effects) {
                effect.cancel();
            }
        }
    }

    public Effect getEffect() {
        return this.effect;
    }

    public void setEffect(Effect effect) {
        this.effect = effect;
    }

    public VirtualProjectile getVirtualProjectile() {
        return this.vp;
    }

    public void setVirtualProjectile(VirtualProjectile vp) {
        this.vp = vp;
    }
}
